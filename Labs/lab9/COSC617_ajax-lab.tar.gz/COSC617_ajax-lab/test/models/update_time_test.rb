require 'test_helper'

class UpdateTimeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
