class UpdateTime < ActiveRecord::Base
end
